
using System;
using System.Collections.Generic;

namespace SimpleCRUDApp
{
    class Program
    {
        static List<string> records = new List<string>();

        static void Main(string[] args)
        {
            int choice;
            do
            {
                Console.WriteLine("\n--- Simple C# CRUD Application ---");
                Console.WriteLine("1. Create Record");
                Console.WriteLine("2. Read Records");
                Console.WriteLine("3. Update Record");
                Console.WriteLine("4. Delete Record");
                Console.WriteLine("5. Exit");
                Console.Write("Enter your choice: ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        CreateRecord();
                        break;
                    case 2:
                        ReadRecords();
                        break;
                    case 3:
                        UpdateRecord();
                        break;
                    case 4:
                        DeleteRecord();
                        break;
                    case 5:
                        Console.WriteLine("Exiting...");
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Try again.");
                        break;
                }

            } while (choice != 5);
        }

        static void CreateRecord()
        {
            Console.Write("Enter new record: ");
            string record = Console.ReadLine();
            records.Add(record);
            Console.WriteLine("Record added successfully.");
        }

        static void ReadRecords()
        {
            Console.WriteLine("\n--- All Records ---");
            for (int i = 0; i < records.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {records[i]}");
            }
        }

        static void UpdateRecord()
        {
            ReadRecords();
            Console.Write("Enter record number to update: ");
            int index = Convert.ToInt32(Console.ReadLine()) - 1;
            if (index >= 0 && index < records.Count)
            {
                Console.Write("Enter new value: ");
                records[index] = Console.ReadLine();
                Console.WriteLine("Record updated successfully.");
            }
            else
            {
                Console.WriteLine("Invalid record number.");
            }
        }

        static void DeleteRecord()
        {
            ReadRecords();
            Console.Write("Enter record number to delete: ");
            int index = Convert.ToInt32(Console.ReadLine()) - 1;
            if (index >= 0 && index < records.Count)
            {
                records.RemoveAt(index);
                Console.WriteLine("Record deleted successfully.");
            }
            else
            {
                Console.WriteLine("Invalid record number.");
            }
        }
    }
}
